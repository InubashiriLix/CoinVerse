package org.openapitools.client.infrastructure

import retrofit2.Response

