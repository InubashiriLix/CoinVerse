
# RefreshTokenRequest

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **oldToken** | **kotlin.String** |  |  |



