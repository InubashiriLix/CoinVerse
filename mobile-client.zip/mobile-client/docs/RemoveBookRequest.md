
# RemoveBookRequest

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **token** | **kotlin.String** |  |  |
| **bookId** | **kotlin.Int** |  |  |



