
# ListBookResponse

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **success** | **kotlin.Boolean** |  |  |
| **code** | **kotlin.Int** |  |  |
| **msg** | **kotlin.String** |  |  |
| **books** | **kotlin.collections.List&lt;kotlin.collections.Map&lt;kotlin.String, kotlin.collections.List&lt;kotlin.Any&gt;&gt;&gt;** |  |  |



