
# HTTPValidationError

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **detail** | [**kotlin.collections.List&lt;ValidationError&gt;**](ValidationError.md) |  |  [optional] |



