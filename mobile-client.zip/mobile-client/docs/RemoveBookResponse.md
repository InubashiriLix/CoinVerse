
# RemoveBookResponse

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **success** | **kotlin.Boolean** |  |  |
| **code** | **kotlin.Int** |  |  |
| **msg** | **kotlin.String** |  |  |



