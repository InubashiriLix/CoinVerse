
# ChangePasswordRequest

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **nameOrEmail** | **kotlin.String** |  |  |
| **oldPwdHash** | **kotlin.String** |  |  |
| **newPwdHash** | **kotlin.String** |  |  |



