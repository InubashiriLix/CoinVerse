
# LoginRequest

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **nameOrEmail** | **kotlin.String** |  |  |
| **pwdHash** | **kotlin.String** |  |  |
| **maintainOnline** | **kotlin.Boolean** |  |  |



