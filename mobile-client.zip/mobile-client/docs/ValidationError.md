
# ValidationError

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **loc** | [**kotlin.collections.List&lt;ValidationErrorLocInner&gt;**](ValidationErrorLocInner.md) |  |  |
| **msg** | **kotlin.String** |  |  |
| **type** | **kotlin.String** |  |  |



