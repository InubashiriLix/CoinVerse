
# RegisterRequest

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **name** | **kotlin.String** |  |  |
| **email** | **kotlin.String** |  |  |
| **pwdHash** | **kotlin.String** |  |  |



