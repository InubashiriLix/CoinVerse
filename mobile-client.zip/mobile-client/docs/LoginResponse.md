
# LoginResponse

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **success** | **kotlin.Boolean** |  |  |
| **msg** | **kotlin.String** |  |  |
| **accessToken** | **kotlin.String** |  |  |
| **tokenType** | **kotlin.String** |  |  [optional] |



