
# BookDetailRequest

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **token** | **kotlin.String** |  |  |
| **accountBookId** | **kotlin.Int** |  |  |
| **startTime** | **kotlin.String** |  |  |
| **endTime** | **kotlin.String** |  |  |
| **note** | **kotlin.String** |  |  |



