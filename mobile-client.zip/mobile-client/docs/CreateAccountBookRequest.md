
# CreateAccountBookRequest

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **token** | **kotlin.String** |  |  |
| **bookName** | **kotlin.String** |  |  |



