
# GetUserProfileResponse

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **success** | **kotlin.Boolean** |  |  |
| **msg** | **kotlin.String** |  |  |
| **name** | **kotlin.String** |  |  |
| **email** | **kotlin.String** |  |  |



