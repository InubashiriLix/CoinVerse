
# AddOutcomeResponse

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **success** | **kotlin.Boolean** |  |  |
| **msg** | **kotlin.String** |  |  |
| **code** | **kotlin.Int** |  |  |



