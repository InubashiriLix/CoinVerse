
# AddOutcomeRequest

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **token** | **kotlin.String** |  |  |
| **accountBookId** | **kotlin.Int** |  |  |
| **amount** | [**java.math.BigDecimal**](java.math.BigDecimal.md) |  |  |
| **time** | **kotlin.String** |  |  |
| **note** | **kotlin.String** |  |  |
| **outcomeIdx** | **kotlin.Int** |  |  |



