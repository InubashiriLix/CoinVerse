
# BookDetailResponse

## Properties
| Name | Type | Description | Notes |
| ------------ | ------------- | ------------- | ------------- |
| **success** | **kotlin.Boolean** |  |  |
| **msg** | **kotlin.String** |  |  |
| **code** | **kotlin.Int** |  |  |
| **transactions** | **kotlin.collections.List&lt;kotlin.collections.Map&lt;kotlin.String, kotlin.collections.List&lt;kotlin.Any&gt;&gt;&gt;** |  |  |



